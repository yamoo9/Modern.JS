export default data => Object.prototype.toString.call(data).toLowerCase().slice(8,-1);
