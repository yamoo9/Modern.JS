(function(global, $){
  'use strict';


})(window, window.jQuery);